import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
export const choose = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choose.url(options),
    method: 'get',
})

choose.definition = {
    methods: ["get","head"],
    url: '/choose',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.url = (options?: RouteQueryOptions) => {
    return choose.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choose.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: choose.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
    const chooseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: choose.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
        chooseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choose.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
        chooseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choose.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    choose.form = chooseForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
export const aboutMedai = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: aboutMedai.url(options),
    method: 'get',
})

aboutMedai.definition = {
    methods: ["get","head"],
    url: '/about-medai',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedai.url = (options?: RouteQueryOptions) => {
    return aboutMedai.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedai.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: aboutMedai.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedai.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: aboutMedai.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
    const aboutMedaiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: aboutMedai.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
        aboutMedaiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: aboutMedai.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedai
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
        aboutMedaiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: aboutMedai.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    aboutMedai.form = aboutMedaiForm
/**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
export const demoLogin = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: demoLogin.url(options),
    method: 'get',
})

demoLogin.definition = {
    methods: ["get","head"],
    url: '/demo-login',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
demoLogin.url = (options?: RouteQueryOptions) => {
    return demoLogin.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
demoLogin.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: demoLogin.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
demoLogin.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: demoLogin.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
    const demoLoginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: demoLogin.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
        demoLoginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: demoLogin.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:39
 * @route '/demo-login'
 */
        demoLoginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: demoLogin.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    demoLogin.form = demoLoginForm
/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm