import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/qbank',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\QBankWebController::index
 * @see app/Http/Controllers/Web/QBankWebController.php:29
 * @route '/qbank'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
export const runner = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runner.url(options),
    method: 'get',
})

runner.definition = {
    methods: ["get","head"],
    url: '/qbank/runner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
runner.url = (options?: RouteQueryOptions) => {
    return runner.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
runner.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runner.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
runner.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: runner.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
    const runnerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: runner.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
        runnerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runner.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\QBankWebController::runner
 * @see app/Http/Controllers/Web/QBankWebController.php:71
 * @route '/qbank/runner'
 */
        runnerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runner.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    runner.form = runnerForm
const qbank = {
    index: Object.assign(index, index),
runner: Object.assign(runner, runner),
}

export default qbank