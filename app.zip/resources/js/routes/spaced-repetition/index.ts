import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/spaced-repetition',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const spacedRepetition = {
    index: Object.assign(index, index),
}

export default spacedRepetition