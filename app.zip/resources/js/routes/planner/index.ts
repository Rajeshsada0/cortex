import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/planner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const planner = {
    index: Object.assign(index, index),
}

export default planner