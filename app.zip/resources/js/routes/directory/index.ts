import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/directory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const directory = {
    index: Object.assign(index, index),
}

export default directory