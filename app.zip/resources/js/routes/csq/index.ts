import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/csq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\CsqWebController::index
 * @see app/Http/Controllers/Web/CsqWebController.php:20
 * @route '/csq'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
export const runner = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runner.url(options),
    method: 'get',
})

runner.definition = {
    methods: ["get","head"],
    url: '/csq/runner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
runner.url = (options?: RouteQueryOptions) => {
    return runner.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
runner.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runner.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
runner.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: runner.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
    const runnerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: runner.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
        runnerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runner.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\CsqWebController::runner
 * @see app/Http/Controllers/Web/CsqWebController.php:61
 * @route '/csq/runner'
 */
        runnerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: runner.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    runner.form = runnerForm
/**
* @see \App\Http\Controllers\Web\CsqWebController::submit
 * @see app/Http/Controllers/Web/CsqWebController.php:115
 * @route '/csq/submit'
 */
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/csq/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\CsqWebController::submit
 * @see app/Http/Controllers/Web/CsqWebController.php:115
 * @route '/csq/submit'
 */
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CsqWebController::submit
 * @see app/Http/Controllers/Web/CsqWebController.php:115
 * @route '/csq/submit'
 */
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\CsqWebController::submit
 * @see app/Http/Controllers/Web/CsqWebController.php:115
 * @route '/csq/submit'
 */
    const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\CsqWebController::submit
 * @see app/Http/Controllers/Web/CsqWebController.php:115
 * @route '/csq/submit'
 */
        submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(options),
            method: 'post',
        })
    
    submit.form = submitForm
const csq = {
    index: Object.assign(index, index),
runner: Object.assign(runner, runner),
submit: Object.assign(submit, submit),
}

export default csq