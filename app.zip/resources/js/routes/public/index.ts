import subjects from './subjects'
const publicMethod = {
    subjects: Object.assign(subjects, subjects),
}

export default publicMethod