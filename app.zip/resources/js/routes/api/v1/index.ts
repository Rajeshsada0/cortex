import examConfigs from './exam-configs'
import users from './users'
import subjects from './subjects'
import analytics from './analytics'
import questions from './questions'
import testSessions from './test-sessions'
import spacedRepetition from './spaced-repetition'
import studyPlanner from './study-planner'
import bookmarks from './bookmarks'
import notes from './notes'
const v1 = {
    examConfigs: Object.assign(examConfigs, examConfigs),
users: Object.assign(users, users),
subjects: Object.assign(subjects, subjects),
analytics: Object.assign(analytics, analytics),
questions: Object.assign(questions, questions),
testSessions: Object.assign(testSessions, testSessions),
spacedRepetition: Object.assign(spacedRepetition, spacedRepetition),
studyPlanner: Object.assign(studyPlanner, studyPlanner),
bookmarks: Object.assign(bookmarks, bookmarks),
notes: Object.assign(notes, notes),
}

export default v1