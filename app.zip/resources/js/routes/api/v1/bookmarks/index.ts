import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/bookmarks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggle
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
export const toggle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/api/v1/bookmarks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggle
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
toggle.url = (options?: RouteQueryOptions) => {
    return toggle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggle
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
toggle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggle
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
    const toggleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggle
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
        toggleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(options),
            method: 'post',
        })
    
    toggle.form = toggleForm
const bookmarks = {
    index: Object.assign(index, index),
toggle: Object.assign(toggle, toggle),
}

export default bookmarks