import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::save
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
export const save = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(options),
    method: 'post',
})

save.definition = {
    methods: ["post"],
    url: '/api/v1/notes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::save
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
save.url = (options?: RouteQueryOptions) => {
    return save.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::save
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
save.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: save.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::save
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
    const saveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: save.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::save
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
        saveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: save.url(options),
            method: 'post',
        })
    
    save.form = saveForm
const notes = {
    save: Object.assign(save, save),
}

export default notes