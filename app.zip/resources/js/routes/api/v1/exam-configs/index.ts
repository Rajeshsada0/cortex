import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
export const show = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/exam-configs/{pathway}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
show.url = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pathway: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pathway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pathway: args.pathway,
                }

    return show.definition.url
            .replace('{pathway}', parsedArgs.pathway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
show.get = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
show.head = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
    const showForm = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
        showForm.get = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\ExamConfigController::show
 * @see app/Http/Controllers/Api/V1/ExamConfigController.php:14
 * @route '/api/v1/exam-configs/{pathway}'
 */
        showForm.head = (args: { pathway: string | number } | [pathway: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const examConfigs = {
    show: Object.assign(show, show),
}

export default examConfigs