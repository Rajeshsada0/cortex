import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
export const subjectProgress = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjectProgress.url(options),
    method: 'get',
})

subjectProgress.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/subject-progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
subjectProgress.url = (options?: RouteQueryOptions) => {
    return subjectProgress.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
subjectProgress.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjectProgress.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
subjectProgress.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subjectProgress.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
    const subjectProgressForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subjectProgress.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
        subjectProgressForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjectProgress.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::subjectProgress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
        subjectProgressForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjectProgress.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subjectProgress.form = subjectProgressForm
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
export const readiness = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: readiness.url(options),
    method: 'get',
})

readiness.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/readiness',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.url = (options?: RouteQueryOptions) => {
    return readiness.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: readiness.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: readiness.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
    const readinessForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: readiness.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
        readinessForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: readiness.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
        readinessForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: readiness.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    readiness.form = readinessForm
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
export const quadrants = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quadrants.url(options),
    method: 'get',
})

quadrants.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/quadrants',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.url = (options?: RouteQueryOptions) => {
    return quadrants.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quadrants.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quadrants.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
    const quadrantsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: quadrants.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
        quadrantsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quadrants.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
        quadrantsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quadrants.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    quadrants.form = quadrantsForm
const analytics = {
    subjectProgress: Object.assign(subjectProgress, subjectProgress),
readiness: Object.assign(readiness, readiness),
quadrants: Object.assign(quadrants, quadrants),
}

export default analytics