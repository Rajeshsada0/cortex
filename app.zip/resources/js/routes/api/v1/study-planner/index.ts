import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/study-planner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::show
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:18
 * @route '/api/v1/study-planner'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::recalculate
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:95
 * @route '/api/v1/study-planner/recalculate'
 */
export const recalculate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/api/v1/study-planner/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::recalculate
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:95
 * @route '/api/v1/study-planner/recalculate'
 */
recalculate.url = (options?: RouteQueryOptions) => {
    return recalculate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::recalculate
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:95
 * @route '/api/v1/study-planner/recalculate'
 */
recalculate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::recalculate
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:95
 * @route '/api/v1/study-planner/recalculate'
 */
    const recalculateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\StudyPlannerController::recalculate
 * @see app/Http/Controllers/Api/V1/StudyPlannerController.php:95
 * @route '/api/v1/study-planner/recalculate'
 */
        recalculateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
const studyPlanner = {
    show: Object.assign(show, show),
recalculate: Object.assign(recalculate, recalculate),
}

export default studyPlanner