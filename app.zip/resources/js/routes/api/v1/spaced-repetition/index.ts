import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
export const due = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: due.url(options),
    method: 'get',
})

due.definition = {
    methods: ["get","head"],
    url: '/api/v1/spaced-repetition/due',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
due.url = (options?: RouteQueryOptions) => {
    return due.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
due.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: due.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
due.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: due.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
    const dueForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: due.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
        dueForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: due.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::due
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:23
 * @route '/api/v1/spaced-repetition/due'
 */
        dueForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: due.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    due.form = dueForm
/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::review
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:71
 * @route '/api/v1/spaced-repetition/review'
 */
export const review = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(options),
    method: 'post',
})

review.definition = {
    methods: ["post"],
    url: '/api/v1/spaced-repetition/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::review
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:71
 * @route '/api/v1/spaced-repetition/review'
 */
review.url = (options?: RouteQueryOptions) => {
    return review.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::review
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:71
 * @route '/api/v1/spaced-repetition/review'
 */
review.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::review
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:71
 * @route '/api/v1/spaced-repetition/review'
 */
    const reviewForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SpacedRepetitionController::review
 * @see app/Http/Controllers/Api/V1/SpacedRepetitionController.php:71
 * @route '/api/v1/spaced-repetition/review'
 */
        reviewForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(options),
            method: 'post',
        })
    
    review.form = reviewForm
const spacedRepetition = {
    due: Object.assign(due, due),
review: Object.assign(review, review),
}

export default spacedRepetition