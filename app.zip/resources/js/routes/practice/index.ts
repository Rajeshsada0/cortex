import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
export const guestLaunch = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: guestLaunch.url(options),
    method: 'get',
})

guestLaunch.definition = {
    methods: ["get","post","head"],
    url: '/practice/guest-launch',
} satisfies RouteDefinition<["get","post","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
guestLaunch.url = (options?: RouteQueryOptions) => {
    return guestLaunch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
guestLaunch.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: guestLaunch.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
guestLaunch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: guestLaunch.url(options),
    method: 'post',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
guestLaunch.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: guestLaunch.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
    const guestLaunchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: guestLaunch.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        guestLaunchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: guestLaunch.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        guestLaunchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: guestLaunch.url(options),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::guestLaunch
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        guestLaunchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: guestLaunch.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    guestLaunch.form = guestLaunchForm
const practice = {
    guestLaunch: Object.assign(guestLaunch, guestLaunch),
}

export default practice