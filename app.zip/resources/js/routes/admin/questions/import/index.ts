import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::process
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
export const process = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

process.definition = {
    methods: ["post"],
    url: '/admin/questions/import',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::process
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
process.url = (options?: RouteQueryOptions) => {
    return process.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::process
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
process.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::process
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
    const processForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: process.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::process
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
        processForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: process.url(options),
            method: 'post',
        })
    
    process.form = processForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
export const template = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: template.url(args, options),
    method: 'get',
})

template.definition = {
    methods: ["get","head"],
    url: '/admin/questions/import/template/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
template.url = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { format: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    format: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        format: args.format,
                }

    return template.definition.url
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
template.get = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: template.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
template.head = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: template.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
    const templateForm = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: template.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
        templateForm.get = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: template.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::template
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
        templateForm.head = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: template.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    template.form = templateForm
const importMethod = {
    process: Object.assign(process, process),
template: Object.assign(template, template),
}

export default importMethod