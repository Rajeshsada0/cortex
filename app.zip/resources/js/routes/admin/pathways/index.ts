import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/pathways',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::index
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:16
 * @route '/admin/pathways'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::store
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:54
 * @route '/admin/pathways'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/pathways',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::store
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:54
 * @route '/admin/pathways'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::store
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:54
 * @route '/admin/pathways'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::store
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:54
 * @route '/admin/pathways'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::store
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:54
 * @route '/admin/pathways'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::update
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:99
 * @route '/admin/pathways/{pathway}'
 */
export const update = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/pathways/{pathway}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::update
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:99
 * @route '/admin/pathways/{pathway}'
 */
update.url = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pathway: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pathway: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pathway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pathway: typeof args.pathway === 'object'
                ? args.pathway.id
                : args.pathway,
                }

    return update.definition.url
            .replace('{pathway}', parsedArgs.pathway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::update
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:99
 * @route '/admin/pathways/{pathway}'
 */
update.put = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::update
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:99
 * @route '/admin/pathways/{pathway}'
 */
    const updateForm = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::update
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:99
 * @route '/admin/pathways/{pathway}'
 */
        updateForm.put = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::destroy
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:146
 * @route '/admin/pathways/{pathway}'
 */
export const destroy = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/pathways/{pathway}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::destroy
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:146
 * @route '/admin/pathways/{pathway}'
 */
destroy.url = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pathway: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pathway: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pathway: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pathway: typeof args.pathway === 'object'
                ? args.pathway.id
                : args.pathway,
                }

    return destroy.definition.url
            .replace('{pathway}', parsedArgs.pathway.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::destroy
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:146
 * @route '/admin/pathways/{pathway}'
 */
destroy.delete = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::destroy
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:146
 * @route '/admin/pathways/{pathway}'
 */
    const destroyForm = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPathwayWebController::destroy
 * @see app/Http/Controllers/Admin/AdminPathwayWebController.php:146
 * @route '/admin/pathways/{pathway}'
 */
        destroyForm.delete = (args: { pathway: number | { id: number } } | [pathway: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const pathways = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default pathways