import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import subjects from './subjects'
import topics from './topics'
import subtopics from './subtopics'
import questions from './questions'
import pathways from './pathways'
import csq from './csq'
import users from './users'
import settings from './settings'
/**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminDashboardWebController::dashboard
 * @see app/Http/Controllers/Admin/AdminDashboardWebController.php:21
 * @route '/admin'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
export const storageLink = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storageLink.url(options),
    method: 'get',
})

storageLink.definition = {
    methods: ["get","head"],
    url: '/admin/storage-link',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
storageLink.url = (options?: RouteQueryOptions) => {
    return storageLink.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
storageLink.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: storageLink.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
storageLink.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: storageLink.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
    const storageLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: storageLink.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
        storageLinkForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storageLink.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:140
 * @route '/admin/storage-link'
 */
        storageLinkForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: storageLink.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    storageLink.form = storageLinkForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
subjects: Object.assign(subjects, subjects),
topics: Object.assign(topics, topics),
subtopics: Object.assign(subtopics, subtopics),
questions: Object.assign(questions, questions),
pathways: Object.assign(pathways, pathways),
csq: Object.assign(csq, csq),
users: Object.assign(users, users),
settings: Object.assign(settings, settings),
storageLink: Object.assign(storageLink, storageLink),
}

export default admin