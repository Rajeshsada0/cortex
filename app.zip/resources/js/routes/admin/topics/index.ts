import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/topics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::index
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:17
 * @route '/admin/topics'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:42
 * @route '/admin/topics'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/topics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:42
 * @route '/admin/topics'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:42
 * @route '/admin/topics'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:42
 * @route '/admin/topics'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:42
 * @route '/admin/topics'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::update
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:64
 * @route '/admin/topics/{topic}'
 */
export const update = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/topics/{topic}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::update
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:64
 * @route '/admin/topics/{topic}'
 */
update.url = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { topic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { topic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    topic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        topic: typeof args.topic === 'object'
                ? args.topic.id
                : args.topic,
                }

    return update.definition.url
            .replace('{topic}', parsedArgs.topic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::update
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:64
 * @route '/admin/topics/{topic}'
 */
update.put = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::update
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:64
 * @route '/admin/topics/{topic}'
 */
    const updateForm = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::update
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:64
 * @route '/admin/topics/{topic}'
 */
        updateForm.put = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:86
 * @route '/admin/topics/{topic}'
 */
export const destroy = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/topics/{topic}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:86
 * @route '/admin/topics/{topic}'
 */
destroy.url = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { topic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { topic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    topic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        topic: typeof args.topic === 'object'
                ? args.topic.id
                : args.topic,
                }

    return destroy.definition.url
            .replace('{topic}', parsedArgs.topic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:86
 * @route '/admin/topics/{topic}'
 */
destroy.delete = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:86
 * @route '/admin/topics/{topic}'
 */
    const destroyForm = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:86
 * @route '/admin/topics/{topic}'
 */
        destroyForm.delete = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const topics = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default topics