import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:102
 * @route '/admin/topics/{topic}/subtopics'
 */
export const store = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/topics/{topic}/subtopics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:102
 * @route '/admin/topics/{topic}/subtopics'
 */
store.url = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { topic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { topic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    topic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        topic: typeof args.topic === 'object'
                ? args.topic.id
                : args.topic,
                }

    return store.definition.url
            .replace('{topic}', parsedArgs.topic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:102
 * @route '/admin/topics/{topic}/subtopics'
 */
store.post = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:102
 * @route '/admin/topics/{topic}/subtopics'
 */
    const storeForm = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::store
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:102
 * @route '/admin/topics/{topic}/subtopics'
 */
        storeForm.post = (args: { topic: number | { id: number } } | [topic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:116
 * @route '/admin/subtopics/{subtopic}'
 */
export const destroy = (args: { subtopic: number | { id: number } } | [subtopic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/subtopics/{subtopic}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:116
 * @route '/admin/subtopics/{subtopic}'
 */
destroy.url = (args: { subtopic: number | { id: number } } | [subtopic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subtopic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subtopic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subtopic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subtopic: typeof args.subtopic === 'object'
                ? args.subtopic.id
                : args.subtopic,
                }

    return destroy.definition.url
            .replace('{subtopic}', parsedArgs.subtopic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:116
 * @route '/admin/subtopics/{subtopic}'
 */
destroy.delete = (args: { subtopic: number | { id: number } } | [subtopic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:116
 * @route '/admin/subtopics/{subtopic}'
 */
    const destroyForm = (args: { subtopic: number | { id: number } } | [subtopic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminTopicWebController::destroy
 * @see app/Http/Controllers/Admin/AdminTopicWebController.php:116
 * @route '/admin/subtopics/{subtopic}'
 */
        destroyForm.delete = (args: { subtopic: number | { id: number } } | [subtopic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const subtopics = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default subtopics