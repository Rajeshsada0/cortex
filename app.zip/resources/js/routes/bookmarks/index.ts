import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/bookmarks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\BookmarkWebController::index
 * @see app/Http/Controllers/Web/BookmarkWebController.php:18
 * @route '/bookmarks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const bookmarks = {
    index: Object.assign(index, index),
}

export default bookmarks