import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mock-exam',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\MockExamWebController::index
 * @see app/Http/Controllers/Web/MockExamWebController.php:27
 * @route '/mock-exam'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\MockExamWebController::launch
 * @see app/Http/Controllers/Web/MockExamWebController.php:91
 * @route '/mock-exam/launch'
 */
export const launch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: launch.url(options),
    method: 'post',
})

launch.definition = {
    methods: ["post"],
    url: '/mock-exam/launch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\MockExamWebController::launch
 * @see app/Http/Controllers/Web/MockExamWebController.php:91
 * @route '/mock-exam/launch'
 */
launch.url = (options?: RouteQueryOptions) => {
    return launch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MockExamWebController::launch
 * @see app/Http/Controllers/Web/MockExamWebController.php:91
 * @route '/mock-exam/launch'
 */
launch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: launch.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\MockExamWebController::launch
 * @see app/Http/Controllers/Web/MockExamWebController.php:91
 * @route '/mock-exam/launch'
 */
    const launchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: launch.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\MockExamWebController::launch
 * @see app/Http/Controllers/Web/MockExamWebController.php:91
 * @route '/mock-exam/launch'
 */
        launchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: launch.url(options),
            method: 'post',
        })
    
    launch.form = launchForm
/**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
export const hall = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hall.url(args, options),
    method: 'get',
})

hall.definition = {
    methods: ["get","head"],
    url: '/mock-exam/{id}/hall',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
hall.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return hall.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
hall.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hall.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
hall.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: hall.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
    const hallForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: hall.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
        hallForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: hall.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\MockExamWebController::hall
 * @see app/Http/Controllers/Web/MockExamWebController.php:61
 * @route '/mock-exam/{id}/hall'
 */
        hallForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: hall.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    hall.form = hallForm
/**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
export const result = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: result.url(args, options),
    method: 'get',
})

result.definition = {
    methods: ["get","head"],
    url: '/mock-exam/{id}/result',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
result.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return result.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
result.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: result.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
result.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: result.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
    const resultForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: result.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
        resultForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: result.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\MockExamWebController::result
 * @see app/Http/Controllers/Web/MockExamWebController.php:121
 * @route '/mock-exam/{id}/result'
 */
        resultForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: result.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    result.form = resultForm
const MockExamWebController = { index, launch, hall, result }

export default MockExamWebController