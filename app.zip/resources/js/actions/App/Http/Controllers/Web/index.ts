import GuestPracticeWebController from './GuestPracticeWebController'
import ExamReportDownloadController from './ExamReportDownloadController'
import DashboardWebController from './DashboardWebController'
import QBankWebController from './QBankWebController'
import DirectoryWebController from './DirectoryWebController'
import MockExamWebController from './MockExamWebController'
import SpacedRepetitionWebController from './SpacedRepetitionWebController'
import StudyPlannerWebController from './StudyPlannerWebController'
import BookmarkWebController from './BookmarkWebController'
import CsqWebController from './CsqWebController'
const Web = {
    GuestPracticeWebController: Object.assign(GuestPracticeWebController, GuestPracticeWebController),
ExamReportDownloadController: Object.assign(ExamReportDownloadController, ExamReportDownloadController),
DashboardWebController: Object.assign(DashboardWebController, DashboardWebController),
QBankWebController: Object.assign(QBankWebController, QBankWebController),
DirectoryWebController: Object.assign(DirectoryWebController, DirectoryWebController),
MockExamWebController: Object.assign(MockExamWebController, MockExamWebController),
SpacedRepetitionWebController: Object.assign(SpacedRepetitionWebController, SpacedRepetitionWebController),
StudyPlannerWebController: Object.assign(StudyPlannerWebController, StudyPlannerWebController),
BookmarkWebController: Object.assign(BookmarkWebController, BookmarkWebController),
CsqWebController: Object.assign(CsqWebController, CsqWebController),
}

export default Web