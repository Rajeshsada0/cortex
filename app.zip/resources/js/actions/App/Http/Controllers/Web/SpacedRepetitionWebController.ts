import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
const SpacedRepetitionWebController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpacedRepetitionWebController.url(options),
    method: 'get',
})

SpacedRepetitionWebController.definition = {
    methods: ["get","head"],
    url: '/spaced-repetition',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
SpacedRepetitionWebController.url = (options?: RouteQueryOptions) => {
    return SpacedRepetitionWebController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
SpacedRepetitionWebController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpacedRepetitionWebController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
SpacedRepetitionWebController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpacedRepetitionWebController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
    const SpacedRepetitionWebControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: SpacedRepetitionWebController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
        SpacedRepetitionWebControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SpacedRepetitionWebController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\SpacedRepetitionWebController::__invoke
 * @see app/Http/Controllers/Web/SpacedRepetitionWebController.php:15
 * @route '/spaced-repetition'
 */
        SpacedRepetitionWebControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SpacedRepetitionWebController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    SpacedRepetitionWebController.form = SpacedRepetitionWebControllerForm
export default SpacedRepetitionWebController