import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
const DirectoryWebController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DirectoryWebController.url(options),
    method: 'get',
})

DirectoryWebController.definition = {
    methods: ["get","head"],
    url: '/directory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
DirectoryWebController.url = (options?: RouteQueryOptions) => {
    return DirectoryWebController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
DirectoryWebController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DirectoryWebController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
DirectoryWebController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DirectoryWebController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
    const DirectoryWebControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DirectoryWebController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
        DirectoryWebControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DirectoryWebController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\DirectoryWebController::__invoke
 * @see app/Http/Controllers/Web/DirectoryWebController.php:15
 * @route '/directory'
 */
        DirectoryWebControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DirectoryWebController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DirectoryWebController.form = DirectoryWebControllerForm
export default DirectoryWebController