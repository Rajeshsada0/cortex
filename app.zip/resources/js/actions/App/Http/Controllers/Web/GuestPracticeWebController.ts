import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
export const choose = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choose.url(options),
    method: 'get',
})

choose.definition = {
    methods: ["get","head"],
    url: '/choose',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.url = (options?: RouteQueryOptions) => {
    return choose.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choose.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
choose.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: choose.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
    const chooseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: choose.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
        chooseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choose.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::choose
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:26
 * @route '/choose'
 */
        chooseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choose.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    choose.form = chooseForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
export const subjects = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjects.url(options),
    method: 'get',
})

subjects.definition = {
    methods: ["get","head"],
    url: '/subjects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
subjects.url = (options?: RouteQueryOptions) => {
    return subjects.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
subjects.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjects.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
subjects.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subjects.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
    const subjectsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subjects.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
        subjectsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjects.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjects
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:103
 * @route '/subjects'
 */
        subjectsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjects.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subjects.form = subjectsForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
export const subjectDetail = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjectDetail.url(args, options),
    method: 'get',
})

subjectDetail.definition = {
    methods: ["get","head"],
    url: '/subjects/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
subjectDetail.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return subjectDetail.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
subjectDetail.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subjectDetail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
subjectDetail.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subjectDetail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
    const subjectDetailForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subjectDetail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
        subjectDetailForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjectDetail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::subjectDetail
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:120
 * @route '/subjects/{slug}'
 */
        subjectDetailForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subjectDetail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subjectDetail.form = subjectDetailForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
export const aboutMedAi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: aboutMedAi.url(options),
    method: 'get',
})

aboutMedAi.definition = {
    methods: ["get","head"],
    url: '/about-medai',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedAi.url = (options?: RouteQueryOptions) => {
    return aboutMedAi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedAi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: aboutMedAi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
aboutMedAi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: aboutMedAi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
    const aboutMedAiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: aboutMedAi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
        aboutMedAiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: aboutMedAi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::aboutMedAi
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:148
 * @route '/about-medai'
 */
        aboutMedAiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: aboutMedAi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    aboutMedAi.form = aboutMedAiForm
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
export const launchGuestPractice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: launchGuestPractice.url(options),
    method: 'get',
})

launchGuestPractice.definition = {
    methods: ["get","post","head"],
    url: '/practice/guest-launch',
} satisfies RouteDefinition<["get","post","head"]>

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
launchGuestPractice.url = (options?: RouteQueryOptions) => {
    return launchGuestPractice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
launchGuestPractice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: launchGuestPractice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
launchGuestPractice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: launchGuestPractice.url(options),
    method: 'post',
})
/**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
launchGuestPractice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: launchGuestPractice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
    const launchGuestPracticeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: launchGuestPractice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        launchGuestPracticeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: launchGuestPractice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        launchGuestPracticeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: launchGuestPractice.url(options),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Web\GuestPracticeWebController::launchGuestPractice
 * @see app/Http/Controllers/Web/GuestPracticeWebController.php:156
 * @route '/practice/guest-launch'
 */
        launchGuestPracticeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: launchGuestPractice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    launchGuestPractice.form = launchGuestPracticeForm
const GuestPracticeWebController = { choose, subjects, subjectDetail, aboutMedAi, launchGuestPractice }

export default GuestPracticeWebController