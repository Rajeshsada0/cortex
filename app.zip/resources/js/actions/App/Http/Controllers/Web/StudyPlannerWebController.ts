import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
const StudyPlannerWebController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: StudyPlannerWebController.url(options),
    method: 'get',
})

StudyPlannerWebController.definition = {
    methods: ["get","head"],
    url: '/planner',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
StudyPlannerWebController.url = (options?: RouteQueryOptions) => {
    return StudyPlannerWebController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
StudyPlannerWebController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: StudyPlannerWebController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
StudyPlannerWebController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: StudyPlannerWebController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
    const StudyPlannerWebControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: StudyPlannerWebController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
        StudyPlannerWebControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: StudyPlannerWebController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\StudyPlannerWebController::__invoke
 * @see app/Http/Controllers/Web/StudyPlannerWebController.php:16
 * @route '/planner'
 */
        StudyPlannerWebControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: StudyPlannerWebController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    StudyPlannerWebController.form = StudyPlannerWebControllerForm
export default StudyPlannerWebController