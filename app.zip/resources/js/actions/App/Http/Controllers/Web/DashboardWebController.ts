import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
const DashboardWebController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardWebController.url(options),
    method: 'get',
})

DashboardWebController.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
DashboardWebController.url = (options?: RouteQueryOptions) => {
    return DashboardWebController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
DashboardWebController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardWebController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
DashboardWebController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardWebController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
    const DashboardWebControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardWebController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
        DashboardWebControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardWebController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\DashboardWebController::__invoke
 * @see app/Http/Controllers/Web/DashboardWebController.php:31
 * @route '/dashboard'
 */
        DashboardWebControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardWebController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardWebController.form = DashboardWebControllerForm
export default DashboardWebController