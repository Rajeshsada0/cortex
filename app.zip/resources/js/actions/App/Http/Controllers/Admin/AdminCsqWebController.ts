import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/csq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::index
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:20
 * @route '/admin/csq'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/csq/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::create
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:93
 * @route '/admin/csq/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::store
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:108
 * @route '/admin/csq'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/csq',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::store
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:108
 * @route '/admin/csq'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::store
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:108
 * @route '/admin/csq'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::store
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:108
 * @route '/admin/csq'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::store
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:108
 * @route '/admin/csq'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
export const edit = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/csq/{csq}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
edit.url = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { csq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { csq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    csq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        csq: typeof args.csq === 'object'
                ? args.csq.id
                : args.csq,
                }

    return edit.definition.url
            .replace('{csq}', parsedArgs.csq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
edit.get = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
edit.head = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
    const editForm = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
        editForm.get = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::edit
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:155
 * @route '/admin/csq/{csq}/edit'
 */
        editForm.head = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::update
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:191
 * @route '/admin/csq/{csq}'
 */
export const update = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/csq/{csq}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::update
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:191
 * @route '/admin/csq/{csq}'
 */
update.url = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { csq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { csq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    csq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        csq: typeof args.csq === 'object'
                ? args.csq.id
                : args.csq,
                }

    return update.definition.url
            .replace('{csq}', parsedArgs.csq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::update
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:191
 * @route '/admin/csq/{csq}'
 */
update.put = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::update
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:191
 * @route '/admin/csq/{csq}'
 */
    const updateForm = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::update
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:191
 * @route '/admin/csq/{csq}'
 */
        updateForm.put = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::destroy
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:241
 * @route '/admin/csq/{csq}'
 */
export const destroy = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/csq/{csq}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::destroy
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:241
 * @route '/admin/csq/{csq}'
 */
destroy.url = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { csq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { csq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    csq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        csq: typeof args.csq === 'object'
                ? args.csq.id
                : args.csq,
                }

    return destroy.definition.url
            .replace('{csq}', parsedArgs.csq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::destroy
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:241
 * @route '/admin/csq/{csq}'
 */
destroy.delete = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::destroy
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:241
 * @route '/admin/csq/{csq}'
 */
    const destroyForm = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::destroy
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:241
 * @route '/admin/csq/{csq}'
 */
        destroyForm.delete = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:251
 * @route '/admin/csq/{csq}/toggle-active'
 */
export const toggleActive = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

toggleActive.definition = {
    methods: ["post"],
    url: '/admin/csq/{csq}/toggle-active',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:251
 * @route '/admin/csq/{csq}/toggle-active'
 */
toggleActive.url = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { csq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { csq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    csq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        csq: typeof args.csq === 'object'
                ? args.csq.id
                : args.csq,
                }

    return toggleActive.definition.url
            .replace('{csq}', parsedArgs.csq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:251
 * @route '/admin/csq/{csq}/toggle-active'
 */
toggleActive.post = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:251
 * @route '/admin/csq/{csq}/toggle-active'
 */
    const toggleActiveForm = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleActive.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminCsqWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminCsqWebController.php:251
 * @route '/admin/csq/{csq}/toggle-active'
 */
        toggleActiveForm.post = (args: { csq: number | { id: number } } | [csq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleActive.url(args, options),
            method: 'post',
        })
    
    toggleActive.form = toggleActiveForm
const AdminCsqWebController = { index, create, store, edit, update, destroy, toggleActive }

export default AdminCsqWebController