import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::index
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:24
 * @route '/admin/questions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/questions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::create
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:102
 * @route '/admin/questions/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::store
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:163
 * @route '/admin/questions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::store
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:163
 * @route '/admin/questions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::store
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:163
 * @route '/admin/questions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::store
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:163
 * @route '/admin/questions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::store
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:163
 * @route '/admin/questions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::uploadImage
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:122
 * @route '/admin/questions/upload-image'
 */
export const uploadImage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadImage.url(options),
    method: 'post',
})

uploadImage.definition = {
    methods: ["post"],
    url: '/admin/questions/upload-image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::uploadImage
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:122
 * @route '/admin/questions/upload-image'
 */
uploadImage.url = (options?: RouteQueryOptions) => {
    return uploadImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::uploadImage
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:122
 * @route '/admin/questions/upload-image'
 */
uploadImage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadImage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::uploadImage
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:122
 * @route '/admin/questions/upload-image'
 */
    const uploadImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadImage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::uploadImage
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:122
 * @route '/admin/questions/upload-image'
 */
        uploadImageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadImage.url(options),
            method: 'post',
        })
    
    uploadImage.form = uploadImageForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
export const importView = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: importView.url(options),
    method: 'get',
})

importView.definition = {
    methods: ["get","head"],
    url: '/admin/questions/import',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
importView.url = (options?: RouteQueryOptions) => {
    return importView.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
importView.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: importView.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
importView.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: importView.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
    const importViewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: importView.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
        importViewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: importView.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importView
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:250
 * @route '/admin/questions/import'
 */
        importViewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: importView.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    importView.form = importViewForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importProcess
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
export const importProcess = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importProcess.url(options),
    method: 'post',
})

importProcess.definition = {
    methods: ["post"],
    url: '/admin/questions/import',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importProcess
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
importProcess.url = (options?: RouteQueryOptions) => {
    return importProcess.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importProcess
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
importProcess.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importProcess.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importProcess
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
    const importProcessForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: importProcess.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::importProcess
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:265
 * @route '/admin/questions/import'
 */
        importProcessForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: importProcess.url(options),
            method: 'post',
        })
    
    importProcess.form = importProcessForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
export const downloadTemplate = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(args, options),
    method: 'get',
})

downloadTemplate.definition = {
    methods: ["get","head"],
    url: '/admin/questions/import/template/{format}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
downloadTemplate.url = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { format: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    format: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        format: args.format,
                }

    return downloadTemplate.definition.url
            .replace('{format}', parsedArgs.format.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
downloadTemplate.get = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
downloadTemplate.head = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadTemplate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
    const downloadTemplateForm = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadTemplate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
        downloadTemplateForm.get = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::downloadTemplate
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:306
 * @route '/admin/questions/import/template/{format}'
 */
        downloadTemplateForm.head = (args: { format: string | number } | [format: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadTemplate.form = downloadTemplateForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
export const edit = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/questions/{question}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
edit.url = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return edit.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
edit.get = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
edit.head = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
    const editForm = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
        editForm.get = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::edit
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:326
 * @route '/admin/questions/{question}/edit'
 */
        editForm.head = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::update
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:348
 * @route '/admin/questions/{question}'
 */
export const update = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/questions/{question}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::update
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:348
 * @route '/admin/questions/{question}'
 */
update.url = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return update.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::update
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:348
 * @route '/admin/questions/{question}'
 */
update.put = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::update
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:348
 * @route '/admin/questions/{question}'
 */
    const updateForm = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::update
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:348
 * @route '/admin/questions/{question}'
 */
        updateForm.put = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::destroy
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:437
 * @route '/admin/questions/{question}'
 */
export const destroy = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/questions/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::destroy
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:437
 * @route '/admin/questions/{question}'
 */
destroy.url = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroy.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::destroy
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:437
 * @route '/admin/questions/{question}'
 */
destroy.delete = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::destroy
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:437
 * @route '/admin/questions/{question}'
 */
    const destroyForm = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::destroy
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:437
 * @route '/admin/questions/{question}'
 */
        destroyForm.delete = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:444
 * @route '/admin/questions/{question}/toggle-active'
 */
export const toggleActive = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

toggleActive.definition = {
    methods: ["post"],
    url: '/admin/questions/{question}/toggle-active',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:444
 * @route '/admin/questions/{question}/toggle-active'
 */
toggleActive.url = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return toggleActive.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:444
 * @route '/admin/questions/{question}/toggle-active'
 */
toggleActive.post = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:444
 * @route '/admin/questions/{question}/toggle-active'
 */
    const toggleActiveForm = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleActive.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminQuestionWebController::toggleActive
 * @see app/Http/Controllers/Admin/AdminQuestionWebController.php:444
 * @route '/admin/questions/{question}/toggle-active'
 */
        toggleActiveForm.post = (args: { question: string | { id: string } } | [question: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleActive.url(args, options),
            method: 'post',
        })
    
    toggleActive.form = toggleActiveForm
const AdminQuestionWebController = { index, create, store, uploadImage, importView, importProcess, downloadTemplate, edit, update, destroy, toggleActive }

export default AdminQuestionWebController