import AdminDashboardWebController from './AdminDashboardWebController'
import AdminSubjectWebController from './AdminSubjectWebController'
import AdminTopicWebController from './AdminTopicWebController'
import AdminQuestionWebController from './AdminQuestionWebController'
import AdminPathwayWebController from './AdminPathwayWebController'
import AdminCsqWebController from './AdminCsqWebController'
import AdminUserWebController from './AdminUserWebController'
import AdminSettingsWebController from './AdminSettingsWebController'
const Admin = {
    AdminDashboardWebController: Object.assign(AdminDashboardWebController, AdminDashboardWebController),
AdminSubjectWebController: Object.assign(AdminSubjectWebController, AdminSubjectWebController),
AdminTopicWebController: Object.assign(AdminTopicWebController, AdminTopicWebController),
AdminQuestionWebController: Object.assign(AdminQuestionWebController, AdminQuestionWebController),
AdminPathwayWebController: Object.assign(AdminPathwayWebController, AdminPathwayWebController),
AdminCsqWebController: Object.assign(AdminCsqWebController, AdminCsqWebController),
AdminUserWebController: Object.assign(AdminUserWebController, AdminUserWebController),
AdminSettingsWebController: Object.assign(AdminSettingsWebController, AdminSettingsWebController),
}

export default Admin