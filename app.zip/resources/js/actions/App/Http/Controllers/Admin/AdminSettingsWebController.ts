import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::index
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:18
 * @route '/admin/settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::update
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:28
 * @route '/admin/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::update
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:28
 * @route '/admin/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::update
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:28
 * @route '/admin/settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::update
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:28
 * @route '/admin/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::update
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:28
 * @route '/admin/settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetLogo
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:111
 * @route '/admin/settings/reset-logo'
 */
export const resetLogo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetLogo.url(options),
    method: 'post',
})

resetLogo.definition = {
    methods: ["post"],
    url: '/admin/settings/reset-logo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetLogo
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:111
 * @route '/admin/settings/reset-logo'
 */
resetLogo.url = (options?: RouteQueryOptions) => {
    return resetLogo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetLogo
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:111
 * @route '/admin/settings/reset-logo'
 */
resetLogo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetLogo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetLogo
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:111
 * @route '/admin/settings/reset-logo'
 */
    const resetLogoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetLogo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetLogo
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:111
 * @route '/admin/settings/reset-logo'
 */
        resetLogoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetLogo.url(options),
            method: 'post',
        })
    
    resetLogo.form = resetLogoForm
/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetFavicon
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:123
 * @route '/admin/settings/reset-favicon'
 */
export const resetFavicon = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetFavicon.url(options),
    method: 'post',
})

resetFavicon.definition = {
    methods: ["post"],
    url: '/admin/settings/reset-favicon',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetFavicon
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:123
 * @route '/admin/settings/reset-favicon'
 */
resetFavicon.url = (options?: RouteQueryOptions) => {
    return resetFavicon.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetFavicon
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:123
 * @route '/admin/settings/reset-favicon'
 */
resetFavicon.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetFavicon.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetFavicon
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:123
 * @route '/admin/settings/reset-favicon'
 */
    const resetFaviconForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetFavicon.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSettingsWebController::resetFavicon
 * @see app/Http/Controllers/Admin/AdminSettingsWebController.php:123
 * @route '/admin/settings/reset-favicon'
 */
        resetFaviconForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetFavicon.url(options),
            method: 'post',
        })
    
    resetFavicon.form = resetFaviconForm
const AdminSettingsWebController = { index, update, resetLogo, resetFavicon }

export default AdminSettingsWebController