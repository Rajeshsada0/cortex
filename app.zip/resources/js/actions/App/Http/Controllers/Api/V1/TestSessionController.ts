import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::store
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:27
 * @route '/api/v1/test-sessions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/test-sessions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::store
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:27
 * @route '/api/v1/test-sessions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::store
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:27
 * @route '/api/v1/test-sessions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::store
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:27
 * @route '/api/v1/test-sessions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::store
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:27
 * @route '/api/v1/test-sessions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/test-sessions/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
    const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
        showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::show
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:72
 * @route '/api/v1/test-sessions/{id}'
 */
        showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::recordAttempt
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:97
 * @route '/api/v1/test-sessions/{id}/attempts'
 */
export const recordAttempt = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordAttempt.url(args, options),
    method: 'post',
})

recordAttempt.definition = {
    methods: ["post"],
    url: '/api/v1/test-sessions/{id}/attempts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::recordAttempt
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:97
 * @route '/api/v1/test-sessions/{id}/attempts'
 */
recordAttempt.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return recordAttempt.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::recordAttempt
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:97
 * @route '/api/v1/test-sessions/{id}/attempts'
 */
recordAttempt.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordAttempt.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::recordAttempt
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:97
 * @route '/api/v1/test-sessions/{id}/attempts'
 */
    const recordAttemptForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recordAttempt.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::recordAttempt
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:97
 * @route '/api/v1/test-sessions/{id}/attempts'
 */
        recordAttemptForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recordAttempt.url(args, options),
            method: 'post',
        })
    
    recordAttempt.form = recordAttemptForm
/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::submit
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:151
 * @route '/api/v1/test-sessions/{id}/submit'
 */
export const submit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/api/v1/test-sessions/{id}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::submit
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:151
 * @route '/api/v1/test-sessions/{id}/submit'
 */
submit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return submit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\TestSessionController::submit
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:151
 * @route '/api/v1/test-sessions/{id}/submit'
 */
submit.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::submit
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:151
 * @route '/api/v1/test-sessions/{id}/submit'
 */
    const submitForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\TestSessionController::submit
 * @see app/Http/Controllers/Api/V1/TestSessionController.php:151
 * @route '/api/v1/test-sessions/{id}/submit'
 */
        submitForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
const TestSessionController = { store, show, recordAttempt, submit }

export default TestSessionController