import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/subjects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::index
 * @see app/Http/Controllers/Api/V1/SubjectController.php:19
 * @route '/api/v1/subjects'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
export const progress = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: progress.url(options),
    method: 'get',
})

progress.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/subject-progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
progress.url = (options?: RouteQueryOptions) => {
    return progress.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
progress.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: progress.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
progress.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: progress.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
    const progressForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: progress.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
        progressForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: progress.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SubjectController::progress
 * @see app/Http/Controllers/Api/V1/SubjectController.php:32
 * @route '/api/v1/analytics/subject-progress'
 */
        progressForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: progress.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    progress.form = progressForm
const SubjectController = { index, progress }

export default SubjectController