import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/bookmarks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::index
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:18
 * @route '/api/v1/bookmarks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggleBookmark
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
export const toggleBookmark = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBookmark.url(options),
    method: 'post',
})

toggleBookmark.definition = {
    methods: ["post"],
    url: '/api/v1/bookmarks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggleBookmark
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
toggleBookmark.url = (options?: RouteQueryOptions) => {
    return toggleBookmark.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggleBookmark
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
toggleBookmark.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBookmark.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggleBookmark
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
    const toggleBookmarkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleBookmark.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::toggleBookmark
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:45
 * @route '/api/v1/bookmarks'
 */
        toggleBookmarkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleBookmark.url(options),
            method: 'post',
        })
    
    toggleBookmark.form = toggleBookmarkForm
/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::saveNote
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
export const saveNote = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveNote.url(options),
    method: 'post',
})

saveNote.definition = {
    methods: ["post"],
    url: '/api/v1/notes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::saveNote
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
saveNote.url = (options?: RouteQueryOptions) => {
    return saveNote.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::saveNote
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
saveNote.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveNote.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::saveNote
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
    const saveNoteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: saveNote.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\BookmarkNoteController::saveNote
 * @see app/Http/Controllers/Api/V1/BookmarkNoteController.php:81
 * @route '/api/v1/notes'
 */
        saveNoteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: saveNote.url(options),
            method: 'post',
        })
    
    saveNote.form = saveNoteForm
const BookmarkNoteController = { index, toggleBookmark, saveNote }

export default BookmarkNoteController