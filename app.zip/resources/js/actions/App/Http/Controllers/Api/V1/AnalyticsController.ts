import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
export const readiness = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: readiness.url(options),
    method: 'get',
})

readiness.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/readiness',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.url = (options?: RouteQueryOptions) => {
    return readiness.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: readiness.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
readiness.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: readiness.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
    const readinessForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: readiness.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
        readinessForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: readiness.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::readiness
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:22
 * @route '/api/v1/analytics/readiness'
 */
        readinessForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: readiness.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    readiness.form = readinessForm
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
export const quadrants = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quadrants.url(options),
    method: 'get',
})

quadrants.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/quadrants',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.url = (options?: RouteQueryOptions) => {
    return quadrants.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quadrants.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
quadrants.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quadrants.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
    const quadrantsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: quadrants.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
        quadrantsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quadrants.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::quadrants
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/quadrants'
 */
        quadrantsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quadrants.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    quadrants.form = quadrantsForm
const AnalyticsController = { readiness, quadrants }

export default AnalyticsController