import ExamConfigController from './ExamConfigController'
import UserController from './UserController'
import SubjectController from './SubjectController'
import QuestionController from './QuestionController'
import TestSessionController from './TestSessionController'
import SpacedRepetitionController from './SpacedRepetitionController'
import AnalyticsController from './AnalyticsController'
import StudyPlannerController from './StudyPlannerController'
import BookmarkNoteController from './BookmarkNoteController'
const V1 = {
    ExamConfigController: Object.assign(ExamConfigController, ExamConfigController),
UserController: Object.assign(UserController, UserController),
SubjectController: Object.assign(SubjectController, SubjectController),
QuestionController: Object.assign(QuestionController, QuestionController),
TestSessionController: Object.assign(TestSessionController, TestSessionController),
SpacedRepetitionController: Object.assign(SpacedRepetitionController, SpacedRepetitionController),
AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
StudyPlannerController: Object.assign(StudyPlannerController, StudyPlannerController),
BookmarkNoteController: Object.assign(BookmarkNoteController, BookmarkNoteController),
}

export default V1