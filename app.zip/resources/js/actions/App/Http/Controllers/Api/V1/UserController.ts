import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/api/v1/users/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
    const meForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: me.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
        meForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\UserController::me
 * @see app/Http/Controllers/Api/V1/UserController.php:15
 * @route '/api/v1/users/me'
 */
        meForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    me.form = meForm
/**
* @see \App\Http\Controllers\Api\V1\UserController::updatePathway
 * @see app/Http/Controllers/Api/V1/UserController.php:38
 * @route '/api/v1/users/me'
 */
export const updatePathway = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePathway.url(options),
    method: 'patch',
})

updatePathway.definition = {
    methods: ["patch"],
    url: '/api/v1/users/me',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\V1\UserController::updatePathway
 * @see app/Http/Controllers/Api/V1/UserController.php:38
 * @route '/api/v1/users/me'
 */
updatePathway.url = (options?: RouteQueryOptions) => {
    return updatePathway.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\UserController::updatePathway
 * @see app/Http/Controllers/Api/V1/UserController.php:38
 * @route '/api/v1/users/me'
 */
updatePathway.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePathway.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\V1\UserController::updatePathway
 * @see app/Http/Controllers/Api/V1/UserController.php:38
 * @route '/api/v1/users/me'
 */
    const updatePathwayForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePathway.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\UserController::updatePathway
 * @see app/Http/Controllers/Api/V1/UserController.php:38
 * @route '/api/v1/users/me'
 */
        updatePathwayForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePathway.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePathway.form = updatePathwayForm
const UserController = { me, updatePathway }

export default UserController